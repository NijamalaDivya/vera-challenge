# Vera / magicpin AI Challenge Bot

Stateful FastAPI implementation for the magicpin Vera challenge.

## Required endpoints

- `POST /v1/context`
- `POST /v1/tick`
- `POST /v1/reply`
- `GET /v1/healthz`
- `GET /v1/metadata`

Optional `POST /v1/teardown` wipes in-memory state when the test ends.

## Challenge-aligned behavior

- Contexts are versioned by `(scope, context_id)`.
- Repeated/smaller versions return HTTP 409 with `stale_version`.
- Invalid scopes return the required HTTP 400 JSON shape.
- `/v1/tick` never emits more than 20 actions.
- Trigger-specific suppression prevents duplicate sends.
- Customer-facing sends require supplied consent and use `send_as=merchant_on_behalf`.
- Merchant-facing messages use the merchant/category/trigger contexts and concrete supplied facts.
- Handles research, compliance, performance, renewal, seasonal, review, milestone, planning, recall, win-back, event, listing, competitor and pharmacy-style trigger families.
- `/v1/reply` handles opt-outs, canned auto-replies, positive intent, time requests, questions and out-of-scope requests.
- No external API or LLM is required, keeping latency deterministic and comfortably below the 30-second judge limit.

## Local run

```bash
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

## Render

Use the included `render.yaml`, or configure:

- Build: `pip install -r requirements.txt`
- Start: `uvicorn app:app --host 0.0.0.0 --port $PORT`
- Health check: `/v1/healthz`

Set `TEAM_NAME`, `TEAM_MEMBERS`, `BOT_MODEL`, `BOT_VERSION`, and `CONTACT_EMAIL` before submission.
